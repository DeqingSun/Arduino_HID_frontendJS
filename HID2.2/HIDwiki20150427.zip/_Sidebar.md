**[Documentation (Home)](https://github.com/NicoHood/HID/wiki)**
* [Features](https://github.com/NicoHood/HID/wiki/Features)
* [Installation](https://github.com/NicoHood/HID/wiki/Installation)
* [Updating](https://github.com/NicoHood/HID/wiki/Updating)
* How to use
 * [Micro/Leonardo](https://github.com/NicoHood/HID/wiki/How-to-use-%28Micro-Leonardo-&-HoodLoader2%29)
 * [HoodLoader2](https://github.com/NicoHood/HID/wiki/How-to-use-%28Micro-Leonardo-&-HoodLoader2%29)
 * [HoodLoader1](https://github.com/NicoHood/HID/wiki/How-to-use-%28HoodLoader1%29)
* [API Documentation](https://github.com/NicoHood/HID/wiki/API-Documentation)
 * [Keyboard](https://github.com/NicoHood/HID/wiki/Keyboard-API)
 * [Mouse](https://github.com/NicoHood/HID/wiki/Mouse-API)
 * [Consumer](https://github.com/NicoHood/HID/wiki/Consumer-API)
 * [System](https://github.com/NicoHood/HID/wiki/System-API)
 * [Gamepad](https://github.com/NicoHood/HID/wiki/Gamepad-API)
 * [CDC Serial](https://github.com/NicoHood/HID/wiki/CDC-Serial-API)
 * [MIDI](https://github.com/NicoHood/HID/wiki/MIDI-API)
* [How it works](https://github.com/NicoHood/HID/wiki/How-it-works)
* [Troubleshoot/FAQ](https://github.com/NicoHood/HID/wiki/Troubleshoot-FAQ)
* [Known Bugs](https://github.com/NicoHood/HID/wiki/Known-Bugs)

**Examples/Projects**
 * [Custom HID](https://github.com/NicoHood/HID/wiki/Adding-custom-HID-report-descriptors)
 * [No USB Functions](https://github.com/NicoHood/HID/wiki/No-USB-Functions)
 * [USB-Serial](https://github.com/NicoHood/HID/wiki/USB-Serial)
 * [Arduino as ISP](https://github.com/NicoHood/HID/wiki/Arduino-as-ISP)
 * [Midi Support](https://github.com/NicoHood/HID/wiki/Midi-Support)
 * [HID Bridge (HL2)](https://github.com/NicoHood/HID/wiki/HID-Bridge-%28HL2%29)
 * [Custom Firmwares (HL2)](https://github.com/NicoHood/HID/wiki/Custom-Firmware-%28HL2%29)
 * [Adding custom boards.txt](https://github.com/NicoHood/HID/wiki/Adding-custom-boards.txt)

**Additional Information**
 * [Useful Links/Credits](https://github.com/NicoHood/HID/wiki/Useful-Links-Credits)
 * [Your Projects](https://github.com/NicoHood/HID/wiki/Your-Projects)
 * [Developer Information](https://github.com/NicoHood/HID/wiki/Developer-Information)
