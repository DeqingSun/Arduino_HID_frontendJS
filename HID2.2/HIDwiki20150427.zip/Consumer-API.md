This API is to control your PCs media player, browser or open special programs.

You are able to press at maximum 4 different keys at the same time.

####`Consumer_(void)`
Consumer_ class. An instance is created by default called **Consumer**.
Use **Consumer** with every function, e.g.: Consumer.begin();

####`Key Definitions`
```cpp
// Media key definitions, see official USB docs for more
#define MEDIA_FAST_FORWARD	0xB3
#define MEDIA_REWIND	0xB4
#define MEDIA_NEXT	0xB5
#define MEDIA_PREVIOUS	0xB6
#define MEDIA_STOP	0xB7
#define MEDIA_PLAY_PAUSE	0xCD

#define MEDIA_VOLUME_MUTE	0xE2
#define MEDIA_VOLUME_UP	0xE9
#define MEDIA_VOLUME_DOWN	0xEA

#define CONSUMER_EMAIL_READER	0x18A
#define CONSUMER_CALCULATOR	0x192
#define CONSUMER_EXPLORER	0x194

#define CONSUMER_BROWSER_HOME	0x223
#define CONSUMER_BROWSER_BACK	0x224
#define CONSUMER_BROWSER_FORWARD	0x225
#define CONSUMER_BROWSER_REFRESH	0x227
#define CONSUMER_BROWSER_BOOKMARKS	0x22A
```

####`void begin(void)`
Releases all button presses. This is needed at the beginning of a sketch in order to send a clean HID report. This is normally used in the setup() function.

####`void end(void)`
Has the same effect as begin().

####`void write(uint16_t m)`
Presses and releases a key. This is the main function you want to use with this API.

####`void press(uint16_t m)`
Pressed a key. Make sure to manually release it afterwards. This might be useful if you want to hold a button longer than just a short tick.

####`void release(uint16_t m)`
Releases a single key. Use this after press() to manually release a specific key.

####`void releaseAll(void)`
Releases all keys, equal to end()

####`HID_ConsumerControlReport_Data_t`
```cpp
typedef union{
	// every usable Consumer key possible, up to 4 keys presses possible
	uint8_t whole8[];
	uint16_t whole16[];
	uint32_t whole32[];
	struct{
		uint16_t key1;
		uint16_t key2;
		uint16_t key3;
		uint16_t key4;
	};
} HID_ConsumerControlReport_Data_t;
```

####Example + Source
* https://github.com/NicoHood/HID/blob/master/examples/HID_Basic/HID_Consumer/HID_Consumer.ino
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/Consumer.h
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/Consumer.cpp