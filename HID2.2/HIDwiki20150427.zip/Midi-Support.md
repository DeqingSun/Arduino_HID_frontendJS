Some people have asked me about Midi support. Midi is available for testing: [issue #2](https://github.com/NicoHood/HID/issues/2) for 32u4 only.
But I will work on a new Midi firmware for the 16u2 that supports of course Midi (HoodLoader2 only). A firmware is something like a pre-compiled sketch. With the difference
that I wont use the Arduino IDE to create this firmware. I will use Lufa and a makefile to compile this firmware. This is more efficient.

When the firmware is done you may upload it via avrdude as described on the HoodLoader2 github page. Then you are able to start the midi with a simple reset
or start the bootloader (HoodLoader2) again with a double reset like you are used to. Then you can reprogram your 328 again.

So be patient, I have a lot of new stuff planned and Midi will come. But you are able to flash other firmwares like HIDuino. Maybe thats all you need.
Install HoodLoader2 and flash the hex file. If it works please leave me some info.

* https://github.com/ddiakopoulos/hiduino
* http://hunt.net.nz/users/darran/weblog/5b7f8/Arduino_UNO_USB_MIDI_firmware.html
* http://arduino.cc/en/Hacking/MidiWith8U2Firmware
* https://github.com/rkistner/arcore
* Also see [issue #2](https://github.com/NicoHood/HID/issues/2)
