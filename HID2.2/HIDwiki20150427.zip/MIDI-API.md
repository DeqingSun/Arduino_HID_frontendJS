Available for testing:
[issue #2](https://github.com/NicoHood/HID/issues/2)