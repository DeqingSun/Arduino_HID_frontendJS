This API is to shut down/sleep/wakeup your PC. Other keys from the USB docs are possible to send but should normally not work.

You are able to press only a single key at the same time.

#####System_(void)
System_ class. An instance is created by default called System. Use System with every function, e.g.: System.begin();

#####void begin(void)
Releases all button presses. This is needed at the beginning of a sketch in order to send a clean HID report. This is normally used in the setup() function.

#####void end(void)
Has the same effect as begin().

#####void write(uint8_t s)
Presses and releases a key. This is the main function you want to use with this API.

#####void press(uint8_t s)
Pressed a key. Make sure to manually release it afterwards. This might be useful if you want to hold a button longer than just a short tick.

#####void release(void)
Releases all keys, equal to releaseAll()

#####void releaseAll(void)
Releases all keys, equal to end()

#####HID_SystemControlReport_Data_t
```cpp
typedef union{
	// every usable system control key possible
	uint8_t whole8[];
	uint8_t key;
} HID_SystemControlReport_Data_t;
```

#####Key Definitions
```cpp
#define SYSTEM_POWER_DOWN	0x81
#define SYSTEM_SLEEP	0x82
#define SYSTEM_WAKE_UP	0x83
```

#####Source
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/System.h
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/System.cpp