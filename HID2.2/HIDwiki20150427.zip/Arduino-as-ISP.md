You want to use your Arduino Leonardo/Micro/16u2/Uno/Mega as ISP as well? Here is a simple fix for the USB AVRs which should now work with any kind of Arduino (Uno and Mega as well). This might be useful if you want to burn new bootloaders to bare 328 chips or the HoodLoader2 to a 16u2 with another Arduino.

Select the **Leonardo/Micro/16u2 board** and upload the Arduino as ISP sketch from *sketchbook/hardware/hid/examples/Project/ArduinoISP* to your board.

![ArduinoISP](pictures/ArduinoISP.png)

Now select the **board you want to flash** and under *Tools->Programmer->Arduino as ISP (Leonardo)*.
Ensure the correct Serial port is selected, wires are also correct (SS Pin10, Pin4 for 16u2) and hit burn bootloader/upload via programmer.

![BurningBootloader](pictures/BurningBootloader.png)

Optional you could use the 16u2 with the older [HoodLoader1 firmware as ISP.](https://github.com/NicoHood/Hoodloader#16u2-as-isp-usage)

#### Things I changed in the sketch:
Change reset pin to pin 10/4 instead of SS
Added SPI library (new begin function corrected the [16u2 bug](https://github.com/NicoHood/HoodLoader2/issues/3))
Change the upload protocol (in programmers.txt)from stk500v1 to arduino to avoid any CDC Serial dtr state problems.