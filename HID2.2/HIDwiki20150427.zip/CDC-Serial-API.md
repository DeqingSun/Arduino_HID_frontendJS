These functions are made for advanced users to grab special CDC information or implement special functions on CDC state changes. This is used in the USB-Serial example.

####`uint32_t baud(void)`
Returns the CDC baud rate.

####`uint8_t stopbits(void)`
Returns the CDC baud rate.

####`uint8_t paritytype(void)`
Returns the CDC parity type.

####`uint8_t numbits(void)`
Returns the CDC bits.

####`bool dtr(void)`
Returns the CDC DTR state.

####`bool rts(void)`
Returns the CDC RTS state.

####`SERIAL_BUFFER_SIZE`
Size of the CDC Serial buffer. Default 64 bytes, for 8u2 and 16u2 only 16 bytes. 32u2 MCUs uses the default buffer size, due to more available ram.

####`USB_EP_SIZE`
Definition for the USB endpoint size. This is by default 64 and may be overwritten by the pins_arduino.h.
For HoodLoader2 this value is 16, since the AVR has smaller DPRAM and it is not possible to use 64 bytes for the EPs. This is because the IDE can only set a global EP size for all endpoints sadly.

####`void CDC_LineEncodingEvent(void)`
weak (empty) implemented function, may be overwritten by the user. This function gets executed if the USB Host changed the CDC Lineendcoding. This happens in the Serial monitor for example or while reprogramming. See USB-Serial example.

####`void CDC_LineStateEvent(void)`
weak (empty) implemented function, may be overwritten by the user. This function gets executed if the USB Host changed the DTR or RTS state. This happens in the Serial monitor for example or while reprogramming. See USB-Serial example.

####Example + Source
* https://github.com/NicoHood/HID/blob/master/examples/Projects/USB-Serial/USB-Serial.ino
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/CDC.h
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/CDC.cpp