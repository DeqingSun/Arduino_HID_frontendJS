See *Projects/USB-Serial.ino* for a fully usable USB-Serial bridge.
This example can act the same as the original Arduino firmware to reprogram the main MCU.

This also shows how to use the new [Serial functions](https://github.com/NicoHood/HID/wiki/CDC-Serial-API).
Keep in mind that the USB_EP_SIZE for the u2 Series is set to 16 bytes, so the Serial buffer is also smaller (normally 64b).