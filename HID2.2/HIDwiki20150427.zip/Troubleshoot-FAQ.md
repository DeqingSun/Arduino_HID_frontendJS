#### Error: Selected board depends on 'HID' core (not installed)
See [issue #9](https://github.com/NicoHood/HID/issues/9).

#### Any random weird problem
is mostly solved by a pc reboot or a port switching. Try another (USB2.0) port if you have any problems with your device.
You might also try it on another pc to see if your OS mixes up drivers. Once I had a problem with my USB-Hub, so ensure to connect it directly.
You could also try a different/shorter USB cable.

#### Switching the HID-Core
might confuse the OS since the USB device changes completely from one second to the other.
**This Problem should not appear anymore with HL2.0.4 and the newer drivers but still for Leonardo/Micro.**
Therefore go to Printers and Devices on Windows and select remove. Reconnect your Arduino and maybe remove it again if its not working properly.
Alternatively you can also restart your PC or use another USB PID (in the boards.txt) to see if its a Windows problem or not.
If you change the USB PID the CDC Driver wont be loaded but you can always reupload a sketch in bootloader mode.

![remove usb device](pictures/remove-device.png)

#### Windows 'lost' the drivers
This happened to me on a specific windows installation after each reboot.
Go to 'This Pc -> Manage -> Device Manager -> Other devices -> HoodLoader2', right click and hit 'Update Driver Software... -> Search automatically [...]'.

#### Gamepads
had several problems over the time. The first thing I'd like to mention is that the calibration windows only updates if you focus it.
Windows only supports gamepads with up to 7 axis and 32 buttons and has problems with more than one Gamepad in a multireport.
Linux has problems when gamepads are in multi reports with a system device for example. It may occur that it display immense axis/buttons or none at all.
The current gamepad setting was tested under windows and ubuntu and seems to work. Feel free to extend the gamepad report at your own risk.

![gamepad](pictures/gamepad.png)

**If you have any other problem, open an issue on github or contact me on my blog.**

####Cannot run program "{runtime.tools.avr-gcc.path}/bin/avr-g++":
There were a few internal changes from 1.6.0/1 to 1.6.2 and newer. You have to upgrade your IDE to the latest release (1.6.3 at the date of writing this).