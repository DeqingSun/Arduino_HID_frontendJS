More specific key definitions for the HID devices can be found here:
* https://github.com/NicoHood/HID/blob/master/avr/cores/hid/USB-Core/HIDTables.h
* http://www.usb.org/developers/hidpage/Hut1_12v2.pdf
* http://www.usb.org/developers/hidpage/HID1_11.pdf