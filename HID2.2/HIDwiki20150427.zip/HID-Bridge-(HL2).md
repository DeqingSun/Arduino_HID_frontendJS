# Under construction via dev tree, not final!

If you want to control your USB device from the main MCU you have to somehow transmit this data to the USB MCU (16u2). Therefore you'd have to create something like a Serial protocol to send the data.

**A protocol is in work and will be published sooner or later.**

Upload the Receiver sketch to the 16u2 and the Transmitter sketch to the main MCU. Here you have to select Arduino Uno/Mega HID-Project.

![Board Selection Picture](pictures/board.png)


###How it works
The HID bridge is communication via Serial between the 16u2 USB MCU and the 328/2560 I/O MCU. The connection is already on the PCB so no need to wire anything. On the 16u2 you have to use Serial1 which stands for the Hardware Serial, because Serial (0) is the CDC USB Serial. The connection runs at fast 2M baud rate because we are working with an acknowledge/request system here, so no buffer overflows.

#####The USB report generation
The I/O MCU includes the HID APIs from the new HID USB-Core. Meaning the user has full access to all easy to use libraries as Keyboard or Gamepad. The SendHIDReport() function is implemented weak, so the HIDBridge library can overwrite it. Instead of sending data to the USB port (because the I/O MCU has no USB port) it send the data to the Serial with a special packed protocol.

#####The Serial Protocol
For the Serial communication I used my own [NHP (NicoHoodProtocol)](https://github.com/NicoHood/NicoHoodProtocol)
which I developed some month ago. I could use it really good in some situation, also here.
Read the official documentation of you want to know how it works exactly.
The protocol is capable of sending up to 4 bytes at 0-63 different addresses or 0-15 short commands. The data is compressed, smaller numbers are sent faster.

#####Sending an HID report
HID reports are send like this:
* Command (number of HID report (1-x)
* Data packets with address of the report ID
* Command 0 (determine end of transfer)

If the report length is not decidable by 4, the other bytes are filled with random numbers from SRAM.
The receiver ignores this additional data.

#####Acknowledge/Request
To ensure that no data is lost, if the USB Host PC receives the data too slow (like a raspberry pi), we are using an acknowledge signal to tell the I/O MCU that the report has flushed to the USB Host.
This acknowledge is sent at address 0 with data set to <not sure yet, TODO>.

Meaning before every sending the I/O MCU checks the Serial for new input and fully empties the Serial buffer. Also because the USB MCU might have reverted an acknowledge (if the USB Host disconnects for example).

#####Continuous state information
What happens if you reset the I/O MCU? Then it needs a new acknowledge signal first to send data. Therefore the USB MCU sends a new acknowledge every interval (about 1 second). So even if the I/O MCU lost an acknowledge, it will be able to continue sending after a new request. Because of this sending every 1 second, the I/O MCU always have to read out the full buffer before sending HID reports, to get the last USB state. The request is the same command as the acknowledge and only needs two bytes of data to send.

#####Serial debug print
What if you need debug print of the I/O MCU? Currently the problem is not solved. I can imagine to filter out this data for normal ASCII bytes (1-127), excluding 0x00 because this data is recognized on an I/O MCU reset and used to determine this reset. Then the user can still use the Serial class.

The other option would be to modify the Serial class. But this would go too deep into the core modification I think. And then people have even more problems to follow my code. I'd rather send it via the same acknowledge system to ensure that no data is lost (due to the very high speed it is possible that normal Serial data is lost if the USB MCU HW Serial buffer is full.

#####Limitations
As mentioned above, the Serial debug print will be limited. Due to the fast data rate and due to the complicated filtering. I will not do a filtering like with HoodLoader1. If you want to debug, you could start the bootloader mode and debug with a lower Serial speed and deactivate the HIDBridge. Or use Softserial for this.

#####Other ideas
Another idea would be to setup a SoftSerial connection at the USB MCU for optional debugging. Then we could use this as special debug line, separated from the USB stuff. This would only work under Arduino environments right now, because the SoftSerial is written in c++ and does not work with Lufa. Also the Lufa firmwares are meant for HID only devices anyways.

#####Problems left
HID Out report is still not supported. Like a feedback of LEDs or raw HID.