**Supported Arduinos (IDE 1.6 or higher!):**
* Uno (with HoodLoader1 or 2)
* Mega (with HoodLoader1 or 2)
* Leonardo
* (Pro)Micro
* Any other 8u2/16u/at90usb162/32u2/32u4 compatible board

**Main features of the new USB-Core:**

* New HID devices(list below)
* HID reports are easier to modify now
* HID APIs are external usable now
* USB Wakeup
* Arduino as ISP support for USB AVRs
* USB-Serial example
* HID Bridge to control USB from the 328/2560
* Smaller flash/ram usage
* More USB Serial functions
* Included the [SoftSerial fix from matthijskooijman](https://github.com/arduino/Arduino/pull/2032)
* u2 Series support (with [HoodLoader2](https://github.com/NicoHood/HoodLoader2))
* [HoodLoader1](https://github.com/NicoHood/HoodLoader) compatible legacy example
* See change log for more additions and fixes

**Supported HID devices:**

* Keyboard with Leds out (modifiers + 6 keys pressed at the same time)
* Mouse (5 buttons, move, wheel) + Absolute Mouse
* Media Keys (4 keys for music player, webbrowser and more)
* System Key (for PC standby/shutdown)
* Gamepad (32 buttons, 4 16bit axis, 2 8bit axis, 2 D-Pads)