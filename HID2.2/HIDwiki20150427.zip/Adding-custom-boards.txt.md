If you want to add a custom board with a 32u4 which has an Arduino IDE compatible bootloader you have two options to do that:

1. Simply edit the existing boards.txt file
2. Create a new, HID compatible hardware definition folder

###1. Edit existing boards.txt file

Its so simple, just see this example (keep attention to the 2nd line as well):

Before:

```
menu.cpu=Processor
##############################################################
promicro16.name=SparkFun Pro Micro 5V/16MHz
promicro16.build.board=AVR_PROMICRO16
promicro16.build.vid.0=0x1B4F
promicro16.build.pid.0=0x9205
promicro16.build.vid.1=0x1B4F
promicro16.build.pid.1=0x9206
promicro16.upload.tool=avrdude
promicro16.upload.protocol=avr109
promicro16.upload.maximum_size=28672
promicro16.upload.data_size=2560
promicro16.upload.speed=57600
promicro16.upload.disable_flushing=true
promicro16.upload.use_1200bps_touch=true
promicro16.upload.wait_for_upload_port=true
promicro16.bootloader.tool=avrdude
promicro16.bootloader.low_fuses=0xff
promicro16.bootloader.high_fuses=0xd8
promicro16.bootloader.extended_fuses=0xcb
promicro16.bootloader.file=caterina/Caterina-promicro16.hex
promicro16.bootloader.unlock_bits=0x3F
promicro16.bootloader.lock_bits=0x2F
promicro16.build.mcu=atmega32u4
promicro16.build.f_cpu=16000000L
promicro16.build.vid=0x1B4F
promicro16.build.pid=0x9206
promicro16.build.usb_product="SparkFun Pro Micro"
promicro16.build.core=arduino:arduino
promicro16.build.variant=promicro
promicro16.build.extra_flags={build.usb_flags}
```

After:
```
menu.cpu=Processor
menu.usbcore=USB Core

##############################################################

promicro16.name=SparkFun Pro Micro 5V/16MHz
promicro16.build.board=AVR_PROMICRO16
promicro16.build.vid.0=0x1B4F
promicro16.build.pid.0=0x9205
promicro16.build.vid.1=0x1B4F
promicro16.build.pid.1=0x9206

promicro16.upload.tool=avrdude
promicro16.upload.protocol=avr109
promicro16.upload.maximum_size=28672
promicro16.upload.data_size=2560
promicro16.upload.speed=57600
promicro16.upload.disable_flushing=true
promicro16.upload.use_1200bps_touch=true
promicro16.upload.wait_for_upload_port=true

promicro16.bootloader.tool=avrdude
promicro16.bootloader.low_fuses=0xff
promicro16.bootloader.high_fuses=0xd8
promicro16.bootloader.extended_fuses=0xcb
promicro16.bootloader.file=caterina/Caterina-promicro16.hex
promicro16.bootloader.unlock_bits=0x3F
promicro16.bootloader.lock_bits=0x2F

promicro16.build.mcu=atmega32u4
promicro16.build.f_cpu=16000000L
promicro16.build.vid=0x1B4F
#promicro16.build.pid=0x9206
promicro16.build.usb_product="SparkFun Pro Micro"
promicro16.build.core=arduino:arduino
#promicro16.build.variant=promicro
promicro16.build.extra_flags={build.usb_flags}

#USB core selection
#HID Project needs to be installed https://github.com/NicoHood/HID
promicro16.menu.usbcore.hid=Serial + Extended HID
promicro16.menu.usbcore.hid.build.variant=HID:leonardo_hid
promicro16.menu.usbcore.hid.build.pid=0x9206
promicro16.menu.usbcore.gamepad=Serial + Gamepad HID
promicro16.menu.usbcore.gamepad.build.variant=HID:leonardo_gamepad
promicro16.menu.usbcore.gamepad.build.pid=0x9206
promicro16.menu.usbcore.custom=Serial + Custom HID
promicro16.menu.usbcore.custom.build.variant=HID:leonardo_custom
promicro16.menu.usbcore.custom.build.pid=0x9206
promicro16.menu.usbcore.USB_CORE=Default Core
promicro16.menu.usbcore.USB_CORE.build.variant=HID:leonardo
promicro16.menu.usbcore.USB_CORE.build.pid=0x9206
promicro16.menu.usbcore.NO_USB=No USB functions
promicro16.menu.usbcore.NO_USB.build.variant=HID:leonardo_no_usb
promicro16.menu.usbcore.NO_USB.build.pid=0x9206
```

###Create a new, HID compatible hardware definition folder

See [HoodLoader2](https://github.com/NicoHood/HoodLoader2) as example for this.