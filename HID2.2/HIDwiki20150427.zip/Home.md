Welcome to the HID wiki!

This documentation is for the most up to data master and some stuff is also for the current dev version.
If you need an older documentation for an older version, please visit the [releases](https://github.com/NicoHood/HID/releases) page.

Click the links on the sidebar to navigate.

You are allowed to add your projects to the 'Your Projects' section.

![Header Picture](wiki/pictures/header.jpg)
