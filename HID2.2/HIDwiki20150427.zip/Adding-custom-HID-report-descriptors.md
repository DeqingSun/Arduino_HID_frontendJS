To create a **custom HID report descriptor** you can edit the file in *avr/variants/leonardo_custom/pins_arduino.h*.
Same for Micro and HoodLoader2. Not all HID reports are playing well together on all OS so I made these pre selections.
With the custom report you can try it out yourself. Everything you need should be in the pins_arduino.h file.

To be continued.