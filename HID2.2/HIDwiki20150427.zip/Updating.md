If you want to update to a newer HID-Project version please read the documentation carefully again since the installation method might have changed.

If you are using any dev version of the HID Project you might want to check for any updates if anything isn't working as excepted since the dev branch is frequently updated. Also make sure to **download the latest HoodLoader2 board definition files** if you also update the HID Project.

###2.1 to 2.2
If you want to upgrade from 2.1 to 2.2 just replace the sketchbook folder with the newer version. You need to install new HL2.0.4 drivers if you are using it.

###2.0 to 2.1
Read the documentation carefully again since the installation method has changed a lot.
You no longer need to overwrite any source files.

###1.8 to 2.0
Overwrite the old files with the new ones.