#### 1. Select the new board via *Tools->Board*
For HoodLoader2 select the 16u2 MCU, for Leonardo/Micro the specific entry.
Ensure HoodLoader2 board definition files are up to date and installed.
The Uno and Mega entry is just for advanced users who want to use the HID-APIs on the main MCU (328/2560) for an [HID Bridge](https://github.com/NicoHood/HID/wiki/HID-Bridge-%28HL2%29).

![Board Selection Picture](pictures/board.png)

#### 2. Select the USB-Core you want to use. You have 5 options here:
* Extended (Keyboard+Leds, Mouse+Absolute, Consumer, System)
* Gamepad (only Gamepad, nothing else usable soon, due to MAC bugs)
* [Custom HID](https://github.com/NicoHood/HID/wiki/Adding-custom-HID-report-descriptors)(Your custom configuration)
* Default Core (Standard Arduino HID: Keyboard, Mouse)
* [No USB Functions](https://github.com/NicoHood/HID/wiki/No-USB-Functions) (No USB functions available, saves ram + flash)

If the device is not recognized correct after switching the USB-Core (which might happen) go to [troubleshoot](https://github.com/NicoHood/HID/wiki/Troubleshoot-FAQ) and have a look for any solutions. With HoodLoader2.0.4 Windows drivers this is now fixed for the u2 Series.

![USB-Core Selection Picture](pictures/usb-core.png)

#### 3. Try the Basic HID examples for each HID device.
You may want to start with the HelloWorld and HID_Basic examples. They are pretty much self explaining.
Ensure that always the correct HID-Core is selected.

![example Picture](pictures/example.png)

#### 4. Deactivate USB-Core to save flash and ram (optional)
If you don't want to use the USB-Core you can also choose under *Tools/USB Core* "No USB functions" to get rid of the USB stuff and save the ram + flah for other stuff.

Due to a bad Leonardo/Micro bootloader you need to add an ISR(interrupt) into every sketch as workaround.
(Otherwise the USB clock is still on and breaks any delay functions).
**This is not needed for HoodLoader2 devices**, since the bootloader does a true watchdog reset on reprogramming and not a simple application jump.

Checkout the 'Leonardo_Micro_NoUSB_Blink' example.

```cpp
// workaround for undefined USBCON has to be placed in every sketch
// otherwise the timings wont work correctly for Leonardo/Micro
ISR(USB_GEN_vect)
{
  UDINT = 0;
}
```