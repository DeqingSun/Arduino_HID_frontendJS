#### 1. Grab the newest Arduino release
HID-Project only works with the new [Arduino IDE 1.6 or newer](http://arduino.cc/en/Main/Software).

#### 2. Install HoodLoader2 (Arduino Uno/Mega only)
For Arduino Micro/Leonardo ignore this step.

For Arduino Uno/Mega first install [HoodLoader2](https://github.com/NicoHood/HoodLoader2) on your 16u2 + the needed software files.
Make sure your HoodLoader2 software is up to date when you also update the HID-Project files.
[HoodLoader1](https://github.com/NicoHood/HoodLoader) is only supported for legacy.

#### 3. Install the HID core files
Installation has changed over the time. You don't have to modify the original core any more.

Ensure that under 'File->Preferences' the correct **sketchbook folder** is selected.

![preferences](pictures/preferences.png)

Put all files into *sketchbook/hardware/HID/*. **You have to rename the folder HID-master to HID.**
Do not install the files as library since it's a hardware definition, not a library.

**Your sketchbook folder should look like this:**

![Installation Picture](pictures/installation.png)

**Restart the IDE and read the how to use section.**