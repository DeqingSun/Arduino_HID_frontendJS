Feel free to add your projects with HID Project, HL1, HL2 here:

* [Gamecube to PC Adapter](https://nicohood.wordpress.com/2015/02/10/diy-gamecube-to-usb-pc-adapter-with-arduino/)
* [Car PC for Mercedes (german)](http://www.artifex-babel.de/de/car-pc/car-pc_de.html)
* [Be the next to add your project](www.arduino.cc)

Press
-----

* [Hackaday](http://hackaday.com/2014/11/30/using-the-second-microcontroller-on-an-arduino/)
* [Atmel Blog](http://blog.atmel.com/2014/12/01/using-the-power-of-two-mcus-on-an-arduino-board/)