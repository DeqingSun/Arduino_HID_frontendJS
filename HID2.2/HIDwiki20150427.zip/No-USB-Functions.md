In order to deactivate the USB Core select as Tools->USB-Core "No USB functions". This would be useful if you want to get rid of the USB stuff and use this ram/flash for other applications.

![USB-Core Selection Picture](pictures/usb-core.png)

Due to a bad bootloader on Leonardo/Micro you have to always add a workaround to every sketch.
HID Project 2.2 provides this ISR already in the board definition file, so no need to use this in the sketch anymore. (this site will be deleted when 2.2 comes out)

This is not needed for HoodLoader2, this bootloader has a fix for that (and maybe other similar) problem.

```cpp
// workaround for undefined USBCON has to be placed in every sketch
// otherwise the timings wont work correctly
ISR(USB_GEN_vect)
{
  UDINT = 0;
}
```

See the Leonardo_Micro_NoUSB_Blink example as reference.